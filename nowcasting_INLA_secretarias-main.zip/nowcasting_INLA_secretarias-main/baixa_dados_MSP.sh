wget -N https://www.prefeitura.sp.gov.br/cidade/secretarias/upload/saude/arquivos/coronavirus/dados-sivep-esus-sao-paulo-sp-jan-jul-2020.csv 

wget -N https://www.prefeitura.sp.gov.br/cidade/secretarias/upload/saude/arquivos/coronavirus/dados-sivep-esus-sao-paulo-sp-ago-nov-2020.csv 
 
wget -N https://www.prefeitura.sp.gov.br/cidade/secretarias/upload/saude/arquivos/coronavirus/dados-sivep-esus-sao-paulo-sp-dez-fev-2021.csv 
 
wget -N https://www.prefeitura.sp.gov.br/cidade/secretarias/upload/saude/arquivos/coronavirus/dados-sivep-esus-sao-paulo-sp-mar-abr-2021.csv 
 
wget -N https://www.prefeitura.sp.gov.br/cidade/secretarias/upload/saude/arquivos/coronavirus/dados-sivep-esus-sao-paulo-sp-mai-jun-2021.csv 
 
wget -N https://www.prefeitura.sp.gov.br/cidade/secretarias/upload/saude/arquivos/coronavirus/dados-sivep-esus-sao-paulo-sp-jul-ago-2021.csv 
 
wget -N https://www.prefeitura.sp.gov.br/cidade/secretarias/upload/saude/arquivos/coronavirus/dados-sivep-esus-sao-paulo-sp-set-dez-2021.csv 
 
wget -N https://www.prefeitura.sp.gov.br/cidade/secretarias/upload/saude/arquivos/coronavirus/dados-sivep-esus-sao-paulo-sp-jan-fev-2022.csv 
